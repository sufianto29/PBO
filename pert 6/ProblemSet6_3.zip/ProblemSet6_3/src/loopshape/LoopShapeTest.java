package loopshape;

public class LoopShapeTest {
    public static void main(String[] args) {
        
        LoopShape.createRectangle(8, 4);

	System.out.println("");

        LoopShape.createTriangle(9);
    }   
}
