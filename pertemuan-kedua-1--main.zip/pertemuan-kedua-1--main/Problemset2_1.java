/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package problemset2_1;

/**
 *
 * @author Lenovo
 */
public class Problemset2_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("  ####");
        System.out.println(" #    #");
        System.out.println("# #  # #");
        System.out.println("#      #");
        System.out.println("# #  # #");
        System.out.println("#  ##  #");
        System.out.println(" #    #");
        System.out.println("  ####");
    }
    
}
