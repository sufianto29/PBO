# pertemuan-kedua-1-
-
